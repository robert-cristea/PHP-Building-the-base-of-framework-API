<?php
require APPROOT . '/views/includes/header.php';
require APPROOT . '/views/includes/navigation.php';
?>

<main>
    <div class="row">
        <div class="container">
            <div class="col s12 m10">
                <div class="card-panel ">
                    <h4>This is blank page</h4>
                </div>
            </div>
        </div>
    </div>
</main>


<?php
require APPROOT . '/views/includes/footer.php';
?>

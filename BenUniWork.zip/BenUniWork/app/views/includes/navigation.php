<div class="navbar-fixed">
  <nav class="cyan darken-3">
    <div class="container">
      <div class="nav-wrapper">
        <a href="<?php echo URLROOT; ?>/" class="brand-logo">MyUniCourseWork</a>
        <ul id="nav-mobile" class="right hide-on-med-and-down">
          <li><a href="<?php echo URLROOT; ?>/about">About</a></li>
          <li><a href="<?php echo URLROOT; ?>/documentation/">Documentation</a></li>
        </ul>
      </div>
    </div>
  </nav>
</div>
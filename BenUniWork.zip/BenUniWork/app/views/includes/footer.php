    <footer class="page-footer cyan darken-3">
      <div class="footer-copyright">
        <div class="container">
        © 2021 Copyright Ben
        <a class="grey-text text-lighten-4 right" href="<?php echo URLROOT; ?>/pages/about">Designed and Developed by Ben</a>
        </div>
      </div>
    </footer>
    <!--JavaScript at end of body for optimized loading-->
    <script type="text/javascript" src="<?php echo URLROOT; ?>/public/js/materialize.min.js"></script>
  </body>
</html>